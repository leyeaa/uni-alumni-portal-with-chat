<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['page' => 'Alumni Details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'Alumni Details']); ?>
    <section id="teachers-singel" class="pt-70 pb-120 gray-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-8">
                    <div class="teachers-left mt-50">
                        <div class="hero">
                            <img src="<?php echo e(asset('profile_pictures/'.$alumniProfile->profile_picture)); ?>" alt="Teachers">
                        </div>
                        <div class="name" style="text-align: center;">
                            <h6><?php echo e($alumniProfile->surname.' '.$alumniProfile->other_names); ?></h6>
                            <span><?php echo e($alumniProfile->position); ?></span>
                        </div>
                        <div class="social" style="text-align: center;">
                            <ul>
                                <li><a href="https://facebook.com/<?php echo e($alumniProfile->facebook); ?>" target="_blank"><i class="fa fa-facebook-square"></i></a></li>
                                <li><a href="https://twitter.com/<?php echo e($alumniProfile->twitter); ?>" target="_blank"><i class="fa fa-twitter-square"></i></a></li>
                                <li><a href="https://linkedin.com/<?php echo e($alumniProfile->linkedin); ?>" target="_blank"><i class="fa fa-linkedin-square"></i></a></li>
                            </ul>
                        </div>
                    </div> <!-- teachers left -->
                </div>
                <div class="col-lg-8">
                    <div class="teachers-right mt-50">
                        <ul class="nav nav-justified" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="active" id="dashboard-tab" data-toggle="tab" href="#dashboard" role="tab" aria-controls="dashboard" aria-selected="true">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a id="reviews-tab" data-toggle="tab" href="#reviews" role="tab" aria-controls="reviews" aria-selected="false">
                                    <?php if(Auth::user()->matricno==$alumniProfile->matricno): ?>
                                        All Messages
                                    <?php else: ?>
                                        Message Board
                                    <?php endif; ?>
                                </a>
                            </li>
                        </ul> <!-- nav -->
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="dashboard" role="tabpanel" aria-labelledby="dashboard-tab">
                                <?php if (isset($component)) { $__componentOriginal228776e883508d72f0898cfa1f828b98 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard','data' => ['alumniProfile' => $alumniProfile]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['alumniProfile' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($alumniProfile)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal228776e883508d72f0898cfa1f828b98)): ?>
<?php $component = $__componentOriginal228776e883508d72f0898cfa1f828b98; ?>
<?php unset($__componentOriginal228776e883508d72f0898cfa1f828b98); ?>
<?php endif; ?>
                            </div>
                            <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
                                <div class="reviews-cont curriculam-cont" style="padding-top: 20px;">
                                    <div class="title" style="text-align: center;">
                                        <h6>Alumni Message Board</h6>
                                    </div>
                                    <?php if(Auth::user()->matricno==$alumniProfile->matricno): ?>
                                        <?php if (isset($component)) { $__componentOriginalebe8e3cfe7f4a314aa9d8dfb29a5368d = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chat-history','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chat-history'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalebe8e3cfe7f4a314aa9d8dfb29a5368d)): ?>
<?php $component = $__componentOriginalebe8e3cfe7f4a314aa9d8dfb29a5368d; ?>
<?php unset($__componentOriginalebe8e3cfe7f4a314aa9d8dfb29a5368d); ?>
<?php endif; ?>
                                    <?php else: ?>
                                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('alumni-chat',['receiver'=>$alumniProfile->matricno]);

$__html = app('livewire')->mount($__name, $__params, '0WrJWTV', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                        <div class="reviews-form">
                                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('send-chat',['receiver'=>$alumniProfile->matricno,'sender'=>Auth::user()->matricno]);

$__html = app('livewire')->mount($__name, $__params, 'cJ5XSim', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                        </div>
                                    <?php endif; ?>
                                </div> <!-- reviews cont -->
                            </div>
                        </div> <!-- tab content -->
                    </div> <!-- teachers right -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\unimedalumni\resources\views/alumni/members-details.blade.php ENDPATH**/ ?>