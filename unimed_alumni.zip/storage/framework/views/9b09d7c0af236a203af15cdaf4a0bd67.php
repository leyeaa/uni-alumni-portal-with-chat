<?php if(session()->has('message')): ?>
    <div x-data="{show: true}" x-init="setTimeout(() => show = false, 6000)" x-show="show" class="col-lg-4 main-btn px-48 py-1 offset-lg-4 text-center" style="position: fixed; top: 0px; left:0px;">
        <p>
            <?php echo e(session('message')); ?>

        </p>
    </div>
<?php endif; ?><?php /**PATH C:\wamp64\www\unimedalumni\resources\views/components/flash-message.blade.php ENDPATH**/ ?>