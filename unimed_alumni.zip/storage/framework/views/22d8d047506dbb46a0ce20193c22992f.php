<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['page' => 'Academic Request History']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'Academic Request History']); ?>
    <section id="news-part" class="pt-115 pb-110">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 mt-100">
                    <div class="category-form">
                        <div class="form-title text-center">
                            <h3>Alumni Member</h3>
                            <span>Academic Requests History</span>
                        </div>
                        <div class="main-form">
                                <div class="row">
                                    <div class="col-md-12" style="padding: 0px; margin:0px;">
                                        <div class="card">
                                            <div class="card-body">
                                              <h5 class="card-title" style="text-align: center; font-style:italic;">Listed below are all the requests you've made to the University</h5>
                                              
                                              <!-- Bordered Table -->
                                              <table class="table table-bordered">
                                                <thead>
                                                  <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Organization</th>
                                                    <th scope="col">Country</th>
                                                    <th scope="col">Service Type</th>
                                                    <th scope="col">Request Mode</th>
                                                    <th scope="col">Status</th>
                                                    <th scope="col">Payment</th>
                                                    <th scope="col">Date</th>
                                                  </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = Auth::user()->serviceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                      <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td>
                                                          <?php if($serviceRequest->status=="PENDING"): ?>
                                                            <a href="/services/<?php echo e($serviceRequest->id); ?>/edit"><?php echo e($serviceRequest->organization); ?></a>
                                                          <?php else: ?>
                                                            <?php echo e($serviceRequest->organization); ?>

                                                          <?php endif; ?>
                                                          
                                                        </td>
                                                        <td><?php echo e($serviceRequest->country); ?></td>
                                                        <td><?php echo e($serviceRequest->service_type); ?></td>
                                                        <td><?php echo e($serviceRequest->request_method); ?></td>
                                                        <td><?php echo e($serviceRequest->status); ?></td>
                                                        <td>
                                                          <?php if($serviceRequest->payment=="UNPAID"): ?>
                                                            <a href="<?php echo e(route('servicePayment',$serviceRequest->id)); ?>">Pay</a>
                                                          <?php else: ?>
                                                            <a href="https://www.unimed.edu.ng/portal/payment_receipt.php?transid=<?php echo e($serviceRequest->transaction_id); ?>">Receipt</a>
                                                          <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($serviceRequest->updated_at->format('d-m-Y')); ?></td>
                                                      </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                      <tr>
                                                        <td colspan="8"><p>You currently do not have any request</p></td>
                                                      </tr>
                                                    <?php endif; ?>
                                                  
                                                  
                                                </tbody>
                                              </table>
                                              <!-- End Bordered Table -->

                                            </div>
                                          </div>
                                    </div>
                                    
                                </div>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\unimedalumni\resources\views/alumni/request-history.blade.php ENDPATH**/ ?>