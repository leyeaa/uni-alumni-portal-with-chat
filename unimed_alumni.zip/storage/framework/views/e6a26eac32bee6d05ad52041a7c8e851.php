<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['page' => 'Alumni Executive']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'Alumni Executive']); ?>
    <section id="teachers-part" class="pt-65 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="section-title mt-20 pb-15">
                        <h5>Alumni Committee</h5>
                        <h2 style="font-size: 36px;">Meet Our Executive Members</h2>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row">
                <div class="col-lg-4 col-sm-6">
                    <div class="singel-teachers mt-30 text-center">
                        <div class="image">
                            <img src="<?php echo e(asset('images/executive/president.jpg')); ?>" alt="Teachers">
                        </div>
                        <div class="cont">
                            <a href="#"><h6>Adesida Adedayo Oluwadamilola</h6></a>
                            <span>President</span>
                        </div>
                    </div> <!-- singel teachers -->
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="singel-teachers mt-30 text-center">
                        <div class="image">
                            <img src="<?php echo e(asset('images/executive/vice_president.jpg')); ?>" alt="Teachers">
                        </div>
                        <div class="cont">
                            <a href="#"><h6>Ajagunna Adebanke</h6></a>
                            <span>Vice President</span>
                        </div>
                    </div> <!-- singel teachers -->
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="singel-teachers mt-30 text-center">
                        <div class="image">
                            <img src="<?php echo e(asset('images/executive/general_secretary.jpg')); ?>" alt="Teachers">
                        </div>
                        <div class="cont">
                            <a href="#"><h6>Kayode Bright</h6></a>
                            <span>General Secretary</span>
                        </div>
                    </div> <!-- singel teachers -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="singel-teachers mt-30 text-center">
                        <div class="image">
                            <img src="<?php echo e(asset('images/executive/treasurer.jpg')); ?>" alt="Teachers">
                        </div>
                        <div class="cont">
                            <a href="#"><h6>Ayiloge Christianah</h6></a>
                            <span>Treasurer</span>
                        </div>
                    </div> <!-- singel teachers -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="singel-teachers mt-30 text-center">
                        <div class="image">
                            <img src="<?php echo e(asset('images/executive/pro.jpg')); ?>" alt="Teachers">
                        </div>
                        <div class="cont">
                            <a href="#"><h6>Kolawole Bridget</h6></a>
                            <span>Public Relations Officer</span>
                        </div>
                    </div> <!-- singel teachers -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="singel-teachers mt-30 text-center">
                        <div class="image">
                            <img src="<?php echo e(asset('images/executive/financial_secretary.jpg')); ?>" alt="Teachers">
                        </div>
                        <div class="cont">
                            <a href="#"><h6>Ogunleye Temiloluwa</h6></a>
                            <span>Financial Secretary</span>
                        </div>
                    </div> <!-- singel teachers -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="singel-teachers mt-30 text-center">
                        <div class="image">
                            <img src="<?php echo e(asset('images/executive/welfare_secretary.jpg')); ?>" alt="Teachers">
                        </div>
                        <div class="cont">
                            <a href="#"><h6>Akinnagbe Benita</h6></a>
                            <span>Welfare Secretary</span>
                        </div>
                    </div> <!-- singel teachers -->
                </div>
                
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\unimedalumni\resources\views/webpages/executives.blade.php ENDPATH**/ ?>