<div class="accordion" id="accordionExample">
    <?php $__empty_1 = true; $__currentLoopData = Auth::user()->participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card">
            <div class="card-header" id="heading<?php echo e($loop->iteration); ?>">
                <a href="#" data-toggle="collapse" data-target="#collapse<?php echo e($loop->iteration); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($loop->iteration); ?>">
                    <ul>
                        <li><img src="<?php echo e(asset('profile_pictures/'.$conversation->thread->otherParticipant->user->alumniProfile->profile_picture)); ?>" alt="teacher" class="inbox_img"></li>
                        <li><span class="head"><?php echo e($conversation->thread->otherParticipant->user->alumniProfile->surname." ".$conversation->thread->otherParticipant->user->alumniProfile->other_names); ?></span></li>
                        <li><span class="time d-none d-md-block"><i class="fa fa-clock-o"></i> <span><?php echo e($conversation->thread->lastMessage->created_at->format('H:i:s d-m-Y')); ?></span></span></li>
                    </ul>
                </a>
            </div>

            <div id="collapse<?php echo e($loop->iteration); ?>" class="collapse <?php echo e($loop->iteration==1 ? ' show':''); ?>" aria-labelledby="heading<?php echo e($loop->iteration); ?>" data-parent="#accordionExample">
                <div class="card-body">
                    <div style="text-align: right; position: absolute; top:30%; left:90%; z-index:9999;"><a href="<?php echo e(route('alumniDetails', $conversation->thread->otherParticipant->user->alumniProfile->id)); ?>">Reply</a></div>
                    <p><?php echo e($conversation->thread->lastMessage->body); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div style="text-align: center;">
        <p style="color: #F00; font-style:italic;">You currently do not have previous conversations</p>
    </div>
    <?php endif; ?>
    
</div><?php /**PATH C:\wamp64\www\unimedalumni\resources\views/components/chat-history.blade.php ENDPATH**/ ?>