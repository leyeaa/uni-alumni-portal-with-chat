<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['alumniProfile']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['alumniProfile']); ?>
<?php foreach (array_filter((['alumniProfile']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="dashboard-cont">
    <div class="singel-dashboard pt-20">
        <h5>Full Name</h5>
        <p><?php echo e($alumniProfile->surname.', '.$alumniProfile->other_names); ?></p>
    </div> <!-- singel dashboard -->
    <div class="singel-dashboard pt-20">
        <div class="row">
            <div class="col-lg-6">
                <h5>Descipline</h5>
                <p><?php echo e($alumniProfile->department); ?></p>
            </div>
            <div class="col-lg-6">
                <h5>Graduation Month & Year</h5>
                <p><?php echo e($alumniProfile->graduation_month.', '.$alumniProfile->graduation_year); ?></p>
            </div>
        </div>
    </div> <!-- singel dashboard -->
    <div class="singel-dashboard pt-20">
        <div class="row">
            <div class="col-lg-6">
                <h5>Employer</h5>
                <p><?php echo e($alumniProfile->employer); ?></p>
            </div>
            <div class="col-lg-6">
                <h5>Position</h5>
                <p><?php echo e($alumniProfile->position); ?></p>
            </div>
        </div>
    </div> <!-- singel dashboard -->
    <div class="singel-dashboard pt-20">
        <h5>Address</h5>
        <p><?php echo e($alumniProfile->address); ?></p>
    </div> <!-- singel dashboard -->
    <div class="singel-dashboard pt-20">
        <div class="row">
            <div class="col-lg-6">
                <h5>Telephone</h5>
                <p><?php echo e($alumniProfile->phone); ?></p>
            </div>
            <div class="col-lg-6">
                <h5>Email</h5>
                <p><?php echo e($alumniProfile->user->email); ?></p>
            </div>
        </div>
    </div> <!-- singel dashboard -->
    <div class="singel-dashboard pt-20">
        <h5>Brief Profile</h5>
        <p style="font-style: italic;"><?php echo e($alumniProfile->brief_profile); ?></p>
    </div> <!-- singel dashboard -->
</div> <!-- dashboard cont --><?php /**PATH C:\wamp64\www\unimedalumni\resources\views/components/dashboard.blade.php ENDPATH**/ ?>