<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['page' => 'Alumni Directory']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'Alumni Directory']); ?>
        <!--====== TEACHERS PART START ======-->
    
        <section id="teachers-part" class="pt-65 pb-120">
            <div class="container alumni-bg pb-30">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="section-title mt-30 pb-15">
                            <h5>Featured Members</h5>
                            <h2>Meet Alumni Members</h2>
                        </div> <!-- section title -->
                    </div>
                    <div class="col-lg-5" style="display: flex; align-items: flex-end;">
                        <div class="contact-from">
                            <div class="main-form">
                                <form action="<?php echo e(route('directory')); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="singel-form form-group">
                                                <input name="search" type="text" placeholder="Surname or Other Names" style="height: 40px;" required="required">
                                            </div> <!-- singel form -->
                                        </div>
                                        <div class="col-md-5">
                                            <div class="singel-form">
                                                <button type="submit" class="main-btn" style="line-height: 40px;">Search!</button>
                                            </div> <!-- singel form -->
                                        </div> 
                                    </div> <!-- row -->
                                </form>
                            </div> <!-- main form -->
                        </div> <!--  contact from -->
                    </div>
                </div> <!-- row -->
                <div class="row">
                    <?php $__currentLoopData = $alumni_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-sm-6">
                            <div class="singel-teachers mt-30 text-center">
                                <div class="image">
                                    <img src="profile_pictures/<?php echo e($alumni->profile_picture); ?>" width="270" height="308" alt="Alumni Members">
                                </div>
                                <div class="cont">
                                    <a href="/alumniDetails/<?php echo e($alumni->id); ?>"><h6><?php echo e($alumni->surname." ".$alumni->other_names); ?></h6></a>
                                    <span><?php echo e($alumni->position); ?></span>
                                </div>
                            </div> <!-- singel teachers -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div> <!-- row -->
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        
                        <?php echo e($alumni_members->links()); ?>

                    </div>
                </div>  
                <!-- row -->
            </div> <!-- container -->
        </section>
        
        <!--====== TEACHERS PART ENDS ======-->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\unimedalumni\resources\views/alumni/directory.blade.php ENDPATH**/ ?>