<div wire:poll.keep-alive.2s>
    
    <!--[if BLOCK]><![endif]--><?php if(!empty($messages)): ?>
        <div id="chatThread" style="overflow: auto; max-height: 300px;">
            <ul>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="singel-reviews <?php echo e(Auth::user()->matricno==$message->matricno ? 'sender':'responder'); ?>">
                            <div class="reviews-author">
                                <div class="author-thum">
                                    <img src="<?php echo e(asset('profile_pictures/'.$message->user->alumniProfile->profile_picture)); ?>" class="messagePic" alt="Reviews">
                                </div>
                                <div class="author-name">
                                    <h6><?php echo e($message->user->name); ?></h6>
                                    <span><?php echo e($message->created_at->format('H:i:s d-m-Y')); ?></span>
                                </div>
                            </div>
                            <div class="reviews-description pt-10">
                                <p><?php echo e($message->body); ?></p>
                            </div>
                            
                        </div> <!-- singel reviews -->
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>
        
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<script type="text/javascript">
    var myDiv = document.getElementById('chatThread');
    myDiv.scrollTop = myDiv.scrollHeight;
    // $("#chatThread").scrollTop($("#chatThread")[0].scrollHeight);
</script>
<?php /**PATH C:\wamp64\www\unimedalumni\resources\views/livewire/alumni-chat.blade.php ENDPATH**/ ?>