<?php

use App\Http\Controllers\AlumniController;
use App\Http\Controllers\GeneralController;
use App\Http\Controllers\ServiceController;
use App\Livewire\AlumniDashboard;
use App\Models\AlumniProfile;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
//Home Page
Route::get('/', [GeneralController::class, 'index'])->name('home')->middleware('guest');
//About us page
Route::get('/about-us', [GeneralController::class, 'about'])->name('about');
//Contact Us Page
Route::get('/contact-us', [GeneralController::class, 'contactUs']);
//Alumni Registration Form
Route::get('/registration', [AlumniController::class, 'registration'])->name('signup');
//Registration Form Submission
Route::post('/register', [AlumniController::class, 'register']);
//Alumni Login
Route::post('/alumni/authenticate', [AlumniController::class, 'authenticate']);
//Alumni Members Directory
Route::get('/directory',[AlumniController::class, 'alumniDirectory'])->name('directory')->middleware('auth');

//View individual profile for update
Route::get('/editProfile', [AlumniController::class, 'profile'])->name('profile');

//edit Password Page
Route::get('/changePassword', [AlumniController::class, 'changePassword'])->name('changePassword');

//Members Details
Route::get('/alumniDetails/{id}', [AlumniController::class, 'alumniDetails'])->name('alumniDetails');

Route::get('/alumniDashboard/', AlumniDashboard::class)->name('alumniDashboard');

//Update Password
Route::put('/updatePassword/{id}', [AlumniController::class, 'updatePassword']);

//Update Profile
Route::patch('/profile/{id}', [AlumniController::class, 'updateProfile']);

Route::post('/logout', [AlumniController::class, 'logout'])->middleware('auth');

//Request Item
Route::get('/services/newRequest', [ServiceController::class, 'services'])->name('services');
//Process Request
Route::post('/services/processRequest', [ServiceController::class, 'processServiceRequest'])->name('processRequest');

//Request History
Route::get('/services/requestHistory', [ServiceController::class, 'requestsHistory'])->name('requestHistory');

//update Request
Route::put('/services/{id}', [ServiceController::class, 'updateServiceRequest'])->name('updateRequest');

//edit Request
Route::get('/services/{id}/edit', [ServiceController::class, 'editServiceRequest'])->name('editRequest');

//Make Payment
Route::get('/services/makePayment/{id}',[ServiceController::class, 'servicePayment'])->name('servicePayment');

//Send Message
Route::post('/sendMessage/{id}', [AlumniController::class,'sendMessage'])->name('sendMessage');

Route::get('/alumniDetails/{id}#reviews',[AlumniController::class,'alumniMessage'])->name('chat');

//send feedback via email
Route::post('/feedback', [GeneralController::class, 'sendFeedback']);

//FUF donation
Route::get('/donate', [GeneralController::class, 'donation'])->name('donation');

//FUF donation
Route::get('/alumniExecutive', [GeneralController::class, 'executive'])->name('executive');

Route::post('/donationInformation', [GeneralController::class, 'donorVerification'])->name('donationData');

Route::fallback(function(){
    return view('webpages.index');
});

